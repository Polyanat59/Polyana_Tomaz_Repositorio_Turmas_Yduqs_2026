import pandas as pd

df = pd.read_excel("tarefa_python.xlsx")

print("Dados originais:")
print(df)

df["MEDIA"] = (df["NOTA 1"] + df["NOTA 2"]) / 2

status = []

for media in df["MEDIA"]:
    if media >= 6:
        status.append("Aprovado")
    else:
        status.append("Reprovado")

df["STATUS"] = status

print("\nResultado final:")
print(df)